%==== Script of 3DEnVar===

load Xreal %True state

%=== Observation Parameters===

